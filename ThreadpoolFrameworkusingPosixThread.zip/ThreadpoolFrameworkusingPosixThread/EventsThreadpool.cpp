//HEADER
#include "headers.h"
#include "EventsThreadpool.h"

//*********************GLOBAL************************************//
long int g_uliThreasholdlimit 	= 0;
long int g_elsecount 			= 0;

// Declaration of thread condition variable
pthread_cond_t cond1 = PTHREAD_COND_INITIALIZER;
// declaring mutex
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

#ifdef DEBUG
pthread_mutex_t g_DebugMutex;
const int res = pthread_mutex_init(&g_DebugMutex, NULL);
volatile long int g_DebugServerRequestCounter;
#endif

//*********************GLOBAL************************************//

//*********************MICRO************************************//
#define PRINTFDEBUG  1
//*********************MICRO************************************//



//DEFINATION FUNCTION
cEventThreadlPool::cEventThreadlPool():doStop(false)
{
	printf("cEventThreadlPool Start Thread: %ld\n", pthread_self());
	m_Stop_add 		= 0;
	m_pWorkerThread 	= NULL;
	m_iWorkerThreadCount 	= 0;
	printf("cEventThreadlPool End Thread: %ld\n", pthread_self());
}

//Description
	
//
bool cEventThreadlPool::Init(int& iNumberofworkerthread, FUNC_CALLBACK pfuncallback)
{
	printf("cEventThreadlPool::Init Start Threadid: %ld.\n", pthread_self());
	if(NULL == pfuncallback || 0 == iNumberofworkerthread)
	{
		printf("Invalid i/p parameter Threadid: %ld.\n", pthread_self());
		return false;
	}

	m_pfnProcessmessage 		= pfuncallback; //set callback function address
	m_iWorkerThreadCount	    	= iNumberofworkerthread;//Set worker thread count
	
	m_pWorkerThread		= new pthread_t[iNumberofworkerthread]; //create array of pthread

	int iRetVal = 0;
	for(int iCounter = 0; iCounter < iNumberofworkerthread; iCounter++)
	{
		iRetVal = pthread_create(&m_pWorkerThread[iCounter], NULL, &cEventThreadlPool::eventsDispatchThreadProc, this);
		if(0 != iRetVal)
		{
			printf("pthread_create fail to create thread.\n");
			
			printf("Going to deallocate memory allocated for worker thread\n");
			if(NULL != m_pWorkerThread)
			{
				delete [] m_pWorkerThread;
				m_pWorkerThread = NULL;
			}
			
			//cleanupthreads();
			return false;
		}
	}

	printf("cEventThreadlPool::Init End Threadid: %ld.\n", pthread_self());
	
	return true;
}


void* cEventThreadlPool::eventsDispatchThreadProc(void* pvEventThreadpool)
{
	P_EVENTDATA 		pstEventDataptr	= NULL;
	void* 			pvEventData		= NULL;
	unsigned long int	pEventDataSize 	= 0;

	printf("eventsDispatchThreadProc: Start Threadid %ld\n", pthread_self());

	if(NULL == pvEventThreadpool)
	{
		printf("Invalid i/p parameters, pvEventThreadpool is NULL Threadid: %ld.\n", pthread_self());
		
		return NULL;
	}

	cEventThreadlPool *evd = static_cast<cEventThreadlPool*>(pvEventThreadpool);
	while(!evd->doStop)
	{
		pstEventDataptr 		= NULL;
		pvEventData 			= NULL;
		pEventDataSize 		= 0;

			// acquire a lock
			pthread_mutex_lock(&lock);
			
			while(evd->eventsQueue.empty())
			{
				printf("%ld Thread Waiting for signal Threadid .\n", pthread_self());
				
				pthread_cond_wait(&cond1, &lock);

				printf("%ld Thread unlocked Threadid.\n", pthread_self());
			}
			
			if(evd->m_Stop_add)
			{
				printf("m_Stop_add become true so going to break: %ld\n", pthread_self());
				
				// release lock
				pthread_mutex_unlock(&lock);
				break;
			}
			
			printf("eventsQueue size before pop_up():: %ld and Threadid:: %ld \n", evd->eventsQueue.size(), pthread_self());
			
			pstEventDataptr = evd->eventsQueue.front();
			evd->eventsQueue.pop();
			printf("eventsQueue size after pop_up():: %ld and Threadid:: %ld\n", evd->eventsQueue.size(), pthread_self());
			
			pvEventData    = pstEventDataptr->pvEventData;
			pEventDataSize = pstEventDataptr->puliEventdatasize;
			
			if(pstEventDataptr != NULL)
			{
				free(pstEventDataptr);
				pstEventDataptr = NULL;
			}
			// release lock
			pthread_mutex_unlock(&lock);
		
		printf("Lock released: Threadid  %ld\n", pthread_self());		
		
		evd->m_pfnProcessmessage(pvEventData, pEventDataSize);
		
		/*if(NULL != pvEventData)
		{
			printf("Deleting pvEventData from eventdispatch queue ThreadId: %ld\n", pthread_self());
			free(pvEventData);
			pvEventData = NULL;
		}	
		*/
	}

	printf("eventsDispatchThreadProc: End Threadid %ld\n", pthread_self());
	
}


int cEventThreadlPool::addevent(void* pHandle_EventData, unsigned long int puliEventDataSize)
{
	printf("cEventThreadlPool::addevent Start, Threadid %ld\n", pthread_self());
	if(NULL == pHandle_EventData || 0 == puliEventDataSize)
	{
		
		printf("addevent:: Invalid i/p parameter and Threadid %ld.\n", pthread_self());
		return -1;
	}

	P_EVENTDATA pEventData = NULL;
	pEventData 		= (P_EVENTDATA)malloc(sizeof(EVENTDATA));
	
	if(NULL == pEventData)
	{
		printf("addevent:: malloc failed to allocate memory and Threadid %ld.\n", pthread_self());
		return -1;
	}
	
	//memcpy(pEventData->pvEventData, pHandle_EventData->pvEventData, *puliEventDataSize);
	pEventData->pvEventData	= pHandle_EventData;
	pEventData->puliEventdatasize  = puliEventDataSize;
	
	pthread_mutex_lock(&lock);
	if(1 == m_Stop_add)
	{
		printf("addevent:: m_Stop_add is true means Deinit called so event add stoped Threadid: %ld\n", pthread_self());
		
		if(NULL != pEventData)
		{
			free(pEventData);
			pEventData = NULL;
		}
	}
	else if(eventsQueue.size() < 1000)//1000 to set max limit of queue
	{
		g_uliThreasholdlimit++;
		printf("addevent:: adding into queue Threadid %ld.\n", pthread_self());
		eventsQueue.push(pEventData);
		printf("addevent:: added into queue, sending calling signal Threadid %ld.\n", pthread_self());
		pthread_cond_signal(&cond1);	
	}
	else
	{
		g_elsecount++;
		printf("addevent:: Queue is overflow Threadid %ld.\n", pthread_self());			
	}
	
	pthread_mutex_unlock(&lock);
	printf("cEventThreadlPool::addevent:: End Threadid %ld\n", pthread_self());
	
	return 0;
}


/*void cEventThreadlPool::cleanupThreads()
{
	printf("cEventThreadlPool::cleanupThreads Start.\n");
	
	m_Stop_add = 1;
	
	//stop all worker thread
	doStop = true;
	
	//notify dispatcher thread that something is happened
	//for this we need to add dummy event so eventsQueue condition will become valid 
	P_EVENTDATA pstDummyData = NULL;
	
	pstDummyData = (P_EVENTDATA) malloc(sizeof(EVENTDATA));
	eventsQueue->push(pstDummyData);
	pthread_cond_broadcast(&cond1);
	
	for(int iCounter = 0; iCounter <= m_iWorkerThreadCount; iCounter++)
	{
		pthread_join(&m_pWorkerThread[iCounter], &rc);
		if(0 != iRetVal)
		{
			printf("Failed to join %ld thread\n", pthread_self());
		}	
	}
	
	printf("Going to deallocate memory allocated for worker thread\n");
	if(NULL != m_pWorkerThread)
	{
		delete [] m_pWorkerThread;
		m_pWorkerThread = NULL;
	}
	
	printf("Going to deallocate memory allocated for eventqueue\n");
	
	P_EVENTDATA pstEventDataptr = NULL;
	while(!eventsQueue->empty())
	{
		pstEventDataptr = eventsQueue->front();
		eventsQueue->pop();
				
		if(pstEventDataptr != NULL)
		{
			free(pstEventDataptr);
			pstEventDataptr = NULL;
		}
	}
	
	printf("cEventThreadlPool::cleanupThreads End.\n");
}
*/

bool cEventThreadlPool::Deinit()
{
	printf("cEventThreadlPool::Deinit Start1 Threadid:: %ld\n", pthread_self());
	m_Stop_add = 1;
	
	while(1)
	{
		// acquire a lock
		sleep(1); 				//Sleep thread for 1 second to allow worker thread acquire lock and process 
		pthread_mutex_lock(&lock);		//remaining
		if(eventsQueue.empty())
		{
			printf("Store is empty so going to stop Threadid %ld.\n", pthread_self());
			pthread_mutex_unlock(&lock);
			break;
		}
		pthread_mutex_unlock(&lock);
	}
	
	//stop all worker thread
	doStop = true;
	
	//notify dispatcher thread that something is happened
	//for this we need to add dummy event so eventsQueue condition will become valid 
	P_EVENTDATA pstDummyData = NULL;
	
	pstDummyData = (P_EVENTDATA) malloc(sizeof(EVENTDATA));
	eventsQueue.push(pstDummyData);
	pthread_cond_broadcast(&cond1);
	
	//stop main thread for worker thread
	void* rc = NULL;
	int iRetVal = 0;
	
	for(int iCounter = 0; iCounter <= m_iWorkerThreadCount; iCounter++)
	{
		pthread_join(m_pWorkerThread[iCounter], &rc);
		if(0 != iRetVal)
		{
			printf("Failed to join %ld thread\n", pthread_self());
		}	
	}
	
	printf("Going to deallocate memory allocated for worker thread Threadid %ld\n", pthread_self());
	if(NULL != m_pWorkerThread)
	{
		delete [] m_pWorkerThread;
		m_pWorkerThread = NULL;
	}
	
	printf("cEventThreadlPool::Deinit End Threadid %ld\n", pthread_self());
	
	return true;
}


cEventThreadlPool::~cEventThreadlPool()
{
	printf("cEventThreadlPool destructor Threadid: %ld\n", pthread_self());
}
