//H E A D E R


#ifndef EVENTDISPATCHER_H_
#define EVENTDISPATCHER_H_
#include "headers.h"
//#include "Mutex.h"
//#include "ConditionVariable.h"
#endif

//typedefs

typedef void*
(*FUNC_CALLBACK)(void* pDataprocess, const unsigned long int puliSize);



//STRUCTURE
#pragma pack(1)
typedef struct tagEventData
{
	unsigned long int 	puliEventdatasize;
	void* 			pvEventData;

	tagEventData()
	{
		Reset();
	}

	void Reset()
	{
		puliEventdatasize = 0;
		pvEventData = NULL;
	}

}EVENTDATA,*P_EVENTDATA;



class cEventThreadlPool
{

public:
	cEventThreadlPool();
	~cEventThreadlPool();

	bool Init(int& iNumberofworkerthread, FUNC_CALLBACK pfuncallback);
	bool Deinit();
	
	int addevent(void* pHandle_EventData, unsigned long int puliEventDataSize);

private:
	int 						m_iWorkerThreadCount;
	int 						m_Stop_add;
	volatile bool 					doStop;
	FUNC_CALLBACK					m_pfnProcessmessage;
	pthread_t* 					m_pWorkerThread;
			
	queue<P_EVENTDATA> 				eventsQueue;
	
	static void* eventsDispatchThreadProc(void*);
	void cleanupThreads();
};

