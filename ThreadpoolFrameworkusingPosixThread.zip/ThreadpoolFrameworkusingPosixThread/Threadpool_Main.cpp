#ifndef THREADPOOL_MAIN
#define THREADPOOL_MAIN
#include "headers.h"
#include "EventsThreadpool.h"
#endif

void* processmesage(void* pDataprocess, const unsigned long int puliSize)
{
	printf("Inside of processmessage ThreadId:: %ld\n", pthread_self());
	
	
	if(pDataprocess != NULL)
	{	
		printf("Deleting pDataprocess from processmessage: %ld\n", pthread_self());
		free(pDataprocess);
		pDataprocess = NULL;
	}
	
	return NULL;
}


int main()
{
	printf("Start of Thread pool main Threadid: %ld\n", pthread_self());
	int iNumberOfWorkerThread = 4;
	cEventThreadlPool cThreadpoolObj;

	cThreadpoolObj.Init(iNumberOfWorkerThread, &processmesage);
	
	for(int i = 0; i < 100; i++)
	{
		P_EVENTDATA pstData = NULL;
		pstData = (P_EVENTDATA) malloc(sizeof(EVENTDATA));
		pstData->puliEventdatasize = sizeof(EVENTDATA);
	
		cThreadpoolObj.addevent(pstData, pstData->puliEventdatasize);	
	}
	
	sleep(10);
	
	cThreadpoolObj.Deinit();
	printf("End of Thread pool Threadid %ld\n", pthread_self());
	
	return 0;
}
