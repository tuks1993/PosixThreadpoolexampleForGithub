#ifndef COMMONHEADER
#define COMMONHEADER
#include <iostream>
#include <sys/types.h>
#include <string.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <deque>
#include <queue>
using namespace  std;
#endif
